﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
    public interface ISweet
    {
        double SugarByVolume { get; set; }
        double ChocolatePercentage { get; set; }
    }
}
