﻿using System;
using CurrencyConverter;

namespace ConsoleApplication8
{
    class Program
    {
        static void Main(string[] args)
        {
            var allCountries = World.Earth.GetAllCountries();

            foreach (var country in allCountries)
            {
                country.PrintInformation();
            }

            Console.WriteLine("Converting...");
        
            var convertedAmount = Converter.Convert(allCountries[0], allCountries[1], 100);

            Console.WriteLine($"Converted sum is {convertedAmount} {allCountries[0].Currency}");

            Console.ReadLine();
        }
    }
}
