﻿using CountryFramework;

namespace World
{
    public sealed class Ukraine : Country
    {
        public override string GetFlagDescription()
        {
            return "1 yellow and 1 blue ribbons";
        }
    }
}
