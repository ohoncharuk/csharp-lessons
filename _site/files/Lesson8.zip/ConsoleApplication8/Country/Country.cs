﻿using System;

namespace CountryFramework
{
    public abstract class Country
    {
        public string Name { get; set; }
        public string Currency { get; set; }

        public void PrintInformation()
        {
            Console.WriteLine(Name);
            Console.WriteLine(Currency);
            Console.WriteLine(this.GetFlagDescription());
        }

        public abstract string GetFlagDescription();
    }
}
