﻿using System;

namespace ConsoleApplication14
{
    public class HideAttribute : Attribute
    {
    }
}