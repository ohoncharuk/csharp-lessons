﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication14
{
    [Destination(Destnations.Console)]
    class User
    {
        [DisplayValue(Text = "First Name")]
        public string FirstName { get; set; }

        [DisplayValue(Text = "Last Name")]
        public string LastName { get; set; }

        [DisplayValue(Text = "Birth Date")]
        public DateTime DateOfBirth { get; set; }

        [DisplayValue(Text = "Email")]
        public string EmailAddress { get; set; }
    }
}
