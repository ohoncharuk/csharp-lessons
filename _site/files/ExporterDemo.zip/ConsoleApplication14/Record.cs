﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication14
{
    [Destination(Destnations.TxtFile)]
    class Record
    {
        [DisplayValue(Text="Name of the record")]
        public string Name { get; set; }

        public string Value { get; set; }

        [DisplayValue(Text = "Created at")]
        public DateTime Created { get; set; }

        [Hide]
        public DateTime Changed { get; set; }
    }
}
