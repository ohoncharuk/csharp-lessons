﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication14
{
    class Program
    {
        static void Main(string[] args)
        {
            var someRecord = new Record
            {
                Name = "Audio File",
                Value = "Pop song",
                Created = DateTime.Now.AddDays(-10),
                Changed = DateTime.Now
            };

            var thomas = new User
            {
                DateOfBirth = DateTime.Today,
                EmailAddress = "thomas@berlin.de",
                FirstName = "Thomas Heinemann"
            };

            Exporter.Export(someRecord);
            Exporter.Export(thomas);
            
            Console.ReadLine();
        }
    }
}
