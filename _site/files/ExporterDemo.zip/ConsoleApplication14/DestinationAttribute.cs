﻿using System;

namespace ConsoleApplication14
{
    public enum Destnations
    {
        Console,
        TxtFile,
        Excel
    }

    public class DestinationAttribute : Attribute
    {
        public Destnations Destination { get; private set; }

        public DestinationAttribute(Destnations destination)
        {
            Destination = destination;
        }
    }
}