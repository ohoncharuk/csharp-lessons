﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication14
{
    class Exporter
    {
        //class is private, since it is not neccesary outside of Exporter class.
        private class ExportValue
        {
            public string Name { get; set; }
            public object Value { get; set; }
        }

        public static void Export<T>(T obj)
        {
            var destinationDetails = (DestinationAttribute)typeof(T).GetCustomAttributes(typeof(DestinationAttribute), false)[0];

            Type objectType = typeof(T);

            PropertyInfo[] propInfos = objectType.GetProperties();

            var values = new List<ExportValue>();
            
            foreach (var propInfo in propInfos.Where(p => !p.IsDefined(typeof(HideAttribute))))
            {
                var propertyName = propInfo.IsDefined(typeof(DisplayValueAttribute), false)
                    ? propInfo.GetCustomAttributes(typeof(DisplayValueAttribute), false)
                        .Cast<DisplayValueAttribute>()
                        .Single()
                        .Text
                    : propInfo.Name;

                var propertyValue = propInfo.GetValue(obj);

                ExportValue exportValue = new ExportValue
                {
                    Name = propertyName,
                    Value = propertyValue
                };

                values.Add(exportValue);
            }

            switch (destinationDetails.Destination)
            {
                case Destnations.Console:
                    foreach (var value in values)
                    {
                        Console.WriteLine($"{value.Name}: {value.Value}");
                    }
                    break;
                case Destnations.Excel:
                    throw new NotImplementedException();
                case Destnations.TxtFile:
                    var sb = new StringBuilder();
                    foreach (var value in values)
                    {
                        sb.AppendLine($"{value.Name}: {value.Value}");
                    }
                    File.WriteAllText("C:\\test\\data.txt", sb.ToString());
                    break;
            }
        }
    }
}
