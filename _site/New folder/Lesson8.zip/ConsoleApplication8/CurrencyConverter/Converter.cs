﻿using CountryFramework;

namespace CurrencyConverter
{
    public static class Converter
    {
        public static double Convert(Country countryFrom, Country countryTo, double amount)
        {
            //ToDo: implement some business logic to convert currencies
            if (countryFrom.Currency == "USD" && countryTo.Currency == "UAH")
            {
                return amount*25;
            }
            else if (countryFrom.Currency == "UAH" && countryTo.Currency == "USD")
            {
                return amount/25;
            }
            else
            {
                return -1;
            }
        }
    }
}
