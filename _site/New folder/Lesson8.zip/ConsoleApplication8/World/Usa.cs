﻿using CountryFramework;

namespace World
{
    sealed class Usa: Country
    {
        public override string GetFlagDescription()
        {
            return "Thirteen horizontal stripes alternating red and white;" +
                    "in the canton, 50 white stars of alternating numbers of " +
                    "six and five per row on a blue field";
        }
    }


}
