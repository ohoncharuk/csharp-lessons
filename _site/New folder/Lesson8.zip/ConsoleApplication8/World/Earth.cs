﻿using CountryFramework;

namespace World
{
    public static class Earth
    {
        private static readonly Country[] _countries;
        static Earth()
        {
            Country ukraine = new Ukraine
            {
                Name = "Ukraine",
                Currency = "UAH"
            };
            
            Country usa = new Usa
            {
                Currency = "USD",
                Name = "United States of America"
            };
            
            _countries = new[] {ukraine, usa};
        }

        public static Country[] GetAllCountries()
        {
            return _countries;
        }
    }
}
