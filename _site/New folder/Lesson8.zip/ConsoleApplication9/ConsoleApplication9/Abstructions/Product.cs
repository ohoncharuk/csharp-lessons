﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
    abstract class Product
    {
        public int ProductId{ get; set; }
        public double Price { get; set; }
        public string Name { get; set; }

        public DateTime ValidTo { get; set; }

        public double Weight { get; set; }
        public double Calories { get; set; }

        public double CalculateCalorificValue()
        {
            return Calories*100/Weight;
        }
    }
}
