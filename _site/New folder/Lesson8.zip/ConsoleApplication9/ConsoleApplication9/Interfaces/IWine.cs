﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
    public interface IWine : IDrink, IAlcohol
    {
        string Type { get; set; }
        string Color { get; set; }

        /// <summary>
        /// Producer's name
        /// </summary>
        string Winery { get; set; }
        
    }
}
