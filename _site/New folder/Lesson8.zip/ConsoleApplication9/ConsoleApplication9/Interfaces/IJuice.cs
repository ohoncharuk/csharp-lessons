﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9
{
    public interface IJuice : IDrink
    {
        string Fruit { get; set; }
        double SugarByVolume { get; set; }
    }
}
