﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication9.Products
{
    class Champaign:Product, IWine
    {
        public int Size { get; set; }
        public double AlcoholByVolume { get; set; }
        public double GetMaximumAllowedWightForHuman()
        {
            throw new NotImplementedException();
        }

        public string Type { get; set; }
        public string Color { get; set; }
        public string Winery { get; set; }
    }
}
